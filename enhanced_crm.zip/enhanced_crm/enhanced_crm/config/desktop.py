from frappe import _

def get_data():
    return [
        {
            "module_name": "Enhanced CRM",
            "color": "#5899DA",
            "icon": "octicon octicon-verified",
            "type": "module",
            "label": "Enhanced CRM"
        }
    ]

