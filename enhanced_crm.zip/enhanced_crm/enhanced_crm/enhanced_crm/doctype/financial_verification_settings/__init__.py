# Allow Python to import this DocType module
