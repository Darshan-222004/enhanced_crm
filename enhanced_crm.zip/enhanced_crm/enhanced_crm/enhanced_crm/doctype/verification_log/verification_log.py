"""Controller for the Verification Log child DocType."""

import frappe
from frappe.model.document import Document


class VerificationLog(Document):
    """Child table storing PAN / IFSC verification responses."""

    pass
